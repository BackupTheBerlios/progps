public abstract class Etat {
	private Troncon _;
}