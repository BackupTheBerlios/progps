public enum Preferance {
	Radars, TypeRoute, Villes, VillesAEviter, Vitesse, Payante, Touristique;
	private User unnamed_User_;
}