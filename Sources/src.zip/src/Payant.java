public class Payant extends Etat {
}