package progps;

import java.awt.*;

import progps.FenetrePrincipale;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//FenetreChargement fen1 = new FenetreChargement(new Frame());
		//fen1.setVisible(true);
		
		FenetrePrincipale fen2 = new FenetrePrincipale();
		fen2.setVisible(true);
	}

}
