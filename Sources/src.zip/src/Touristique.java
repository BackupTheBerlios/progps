public class Touristique extends Etat {
}