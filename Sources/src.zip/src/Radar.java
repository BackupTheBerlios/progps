public class Radar extends Etat {
}